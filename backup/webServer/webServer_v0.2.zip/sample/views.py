from django.shortcuts import render
from sample.models import SampleModel
	
def mapviews(request):
	samplemodels = SampleModel.objects.all()
	context = {'samplemodels': samplemodels}
	return render(request, 'sample/index.html', context)

def deleteMarker(request):
	lat = request.GET['lat']
	lng = request.GET['lng']
	address = str(lat) + ", " + str(lng)
	samplemodel = SampleModel.objects.get(address = address)
	samplemodel.delete()
	
	samplemodels = SampleModel.objects.all()
	context = {'samplemodels': samplemodels}
	return render(request, 'sample/index.html', context)